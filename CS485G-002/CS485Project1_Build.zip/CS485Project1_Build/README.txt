Title:  Blessed
Author: Ian Rogers
Date:   10/13/19
Class:  485G-002

Game Premise:
- You play as a Hero, whose bow is blessed by the gods. The Hero has been sent to retrieve the Gem of the Forest from the corrupted Treant Lord. 
- The game is a top-down 2D action/adventure game. The game mainly serves as a prototype and can be completed in roughly 3-5 minutes.

Controls:
- WASD - Movement
- Arrow Keys - Directional Bow Shot
- Escape - Pause

Other Important Info:
- As the Hero takes damage their "Divine Power" (denoted by the Power Slider in game) increases making their shots do more damage. 
- The Hero is invulnerable for 0.5 seconds after getting "hit" (really just touched) by an enemy.
- Killing regular enemies restore 1 health, killing the boss restores 5 health.
- Some enemies can only be killed if the Hero is fully powered up (The boss).
- I tested the build of the game on 1920x1080, if you're planning on using a different resolution you might notice UI scaling issues.

Bugs:
- UI Scaling Issues on certain resolutions.
- Sometimes 1 arrow can hit multiple enemies given the right conditions.
- Sometimes the player can appear to move through larger enemy types. This is really only noticeable if you're behind the larger enemies.
- Large enemies can sometimes hit you from further away.

Regarding the Proposal:
- Title Berserker reworked to Blessed.
- Rage mechanic reworked to Divine Power.
- Viking theme reworked to Zelda-like forest theme.

Notes:
If I had Time:
- I would've added sound.
- I would've made the Divine Power mechanic less of a gimmick.
- I would've added more enemy types with more mechanics, for instance enemies that shoot at you, etc.
Thanks for playing!

Sources:
 - https://www.youtube.com/watch?v=whzomFgjT50 - TOP DOWN MOVEMENT in Unity! by Brackeys
 - https://www.youtube.com/watch?v=LNLVOjbrQj4 - TOP DOWN SHOOTING in Unity by Brackeys
 - https://www.youtube.com/watch?v=ryISV_nH8qw - TILEMAPS in Unity by Brackeys
 - https://www.youtube.com/watch?v=JivuXdrIHK0 - PAUSE MENU in Unity by Brackeys
 - https://www.youtube.com/watch?v=zc8ac_qUXQY - START MENU in Unity by Brackeys
