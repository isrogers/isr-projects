#pragma once
//-----------------------------------------------------------
//                           scanner.h
//-----------------------------------------------------------
// This class implements a scanner (lexical analyzer) for a
// compiler. Its primary function is to get the next Token
// from the source file.
//-----------------------------------------------------------
#include <fstream>
#include <string>
#include "fsa.h"
#include "token.h"
#include "symTbl.h"

using namespace std;

class scanner {
public:
	int	   open(string source);	
	string getError() { return error; }
	bool   isError()  { return is_error; }
	token  getNextToken();
	void   close();
private: 
	string error = "";
	bool   is_error = false;
	int    lineNo = 1;
	ifstream f;
	symTbl  symbolTbl;
	token setTokEOF (token t);
	token setTokError (token t, string message);
	TOKENID idLookup (string lex, bool &isReserved);
	TOKENID tokCatLookup (int tokCat);
	string toCaps (string s);
	CHAR_CAT categorize(char c);
	void    setError(string method, char c, string msg);
	int     getTrans(FSA_STATE currState, char c);
	string  getFSAerror(CHAR_CAT cc, FSA_STATE state);
	string  getNextLexeme();
};





