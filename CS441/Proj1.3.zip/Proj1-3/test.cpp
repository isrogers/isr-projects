//------------------------------------------------
//           test program for project 1.3
//------------------------------------------------
#include <iostream>
#include <fstream>
#include "scanner.h"

int  main(int argc, char** argv) {
	scanner s;
	string  lex, fileName;
	token   t;

	// get file name from command line, or ask user
	if (argc > 1)
		fileName = argv[1];
	else {
		cout << "Enter file name: ";
		getline(cin,fileName);
	}

	// open file in scanner
	s.open(fileName);
	if (s.isError()) {
		cout << "Error opening file " << fileName << ". \nPress ENTER to continue..." << endl;
		getchar();
		return 1;
	}

	// repeat until error or End Of Source (TOK_EOS)
	t = s.getNextToken();
	while (!s.isError() && t.getId() != TOK_EOS) {
		cout << t.getPrintString();
		t = s.getNextToken();
	}

	// print error if found
	if (s.isError()) cout << s.getError() << endl;

	cout << "Press ENTER to continue...";
	getchar();
	return 0;
}
