#include <iostream>
#include "scanner.h"

//Name:				scanner.cpp
//Author: 			Ian Rogers
//Class: 			Kevin Joiner's CS441G
//Date:	 			11/8/19
//private methods added:	setTokEOF, setTokError, idLookup, tokCatLookup, toCaps
//-----------------------------------------------------------------------------------
//                                 getNextToken
//-----------------------------------------------------------------------------------
token 	scanner::getNextToken() {
	token t; //initializations
	bool isReserved = false; 
	string lex = getNextLexeme(); //initialize lex as getNextLexeme
	//if there's an error set the error and print the message
	if (is_error) return setTokError(t, "UNKNOWN ERROR in getNextToken()");
	if (lex == "") return setTokEOF(t); //if EOF set EOF
	TOKENID id = idLookup(lex, isReserved); //lookup id of lexeme; isReserved is PBR
	if (isReserved) { //if isReserved is true
		t.setId(id); //set id to the id of the reserved word
		t.setRef(NULL); //ref is null
	} else { //else
		symbolTbl.insert(lex); //insert the lex into the table 
		symTblRef ref = symbolTbl.search(lex); //get the ref id
		if (ref != NULL) { //if search fails, then insert failed
			t.setRef(ref); //use setRef from token.h to set table ref
			int tokCat = ref->getCategory(); //get the category using getCategory from symTbl.h
			id = tokCatLookup(tokCat); //lookup what the token_id of the category is
			t.setId(id); //set the id 
		} else {
			//insert error
			return setTokError(t, "INSERT ERROR in getNextToken()");
		}
	}
	return t;
} // getNextToken()
//-----------------------------------------------------------------------------------
//                                 setTokEOF
//-----------------------------------------------------------------------------------
token	scanner::setTokEOF(token t) {
	t.setId(TOK_EOS); //setId as TOK_EOS
	return t; //return
} // setTokEOF()

//-----------------------------------------------------------------------------------
//                                 setTokError
//-----------------------------------------------------------------------------------
token	scanner::setTokError(token t, string message) {
	is_error = true; //set is_error to true
	t.setId(TOK_ERROR); //set id to TOK_ERROR
	cout << message << endl; //print message
	return t; //return
} // setTokError()

//-----------------------------------------------------------------------------------
//                                 idLookup
//-----------------------------------------------------------------------------------
TOKENID	scanner::idLookup(string lex, bool & isReserved) {
	for (int i = 0; i < NUM_TOKENIDS; i++) { //iterates through const string table of TOKENIDs
		string tokenid = TOKENID_STR[i];
		string upperLex = toCaps(lex); //call toCaps
		if (upperLex == tokenid) {
			isReserved = true; //if theres a match return
			return (TOKENID) i;
		}	
	}
} // idLookup()

//-----------------------------------------------------------------------------------
//                                 tokCatLookup
//-----------------------------------------------------------------------------------
TOKENID	scanner::tokCatLookup(int tokCat) { //returns the id value of the given category
	if (tokCat == SYMCAT_IDENT) return TOK_IDENT; 
	if (tokCat == SYMCAT_INT_LIT) return TOK_INT_LIT;
	if (tokCat == SYMCAT_REAL_LIT) return TOK_REAL_LIT;
	if (tokCat == SYMCAT_STRING_LIT) return TOK_STRING_LIT;
} // tokCatLookup()

//-----------------------------------------------------------------------------------
//                                 toCaps
//-----------------------------------------------------------------------------------
string 	scanner::toCaps(string s) { //converts a string to allcaps
	for (int i=0; i < s.length(); i++)
		s[i] = toupper(s[i]);
	return s;
} // toCaps

//-----------------------------------------------------------------------------------
//                                 open
//-----------------------------------------------------------------------------------
int	scanner::open(string source) {
	f.open(source);
	if (f.fail()) {
		setError("open()", ' ', "Unable to open input file.");
		return 0;
	}
	return 1;
} // open()

//-----------------------------------------------------------------------------------
//                                close
//-----------------------------------------------------------------------------------
void scanner::close() {
	f.close(); // close the source file
} // close()

//-----------------------------------------------------------------------------------
//                                 categorize
//-----------------------------------------------------------------------------------
CHAR_CAT scanner::categorize(char c) {
	if (isalpha(c)) return ALPHA;
	if (isdigit(c)) return DIGIT;
	switch (c) {
	case -1:   return EOFL;
	case '\n': lineNo++; return EOL;
	case '\r': return EOL;
	case ' ':  
	case '\t': return WHITESP;
	case '\'': return QUOTE;
	case '{':  return LBRACE;
	case '}':  return RBRACE;
	case '_':  return UNDERSC;
	case '.':  return DOTC;
	case '>':  return GTHANC;
	case '<':  return LTHANC;
	case ':':  return COLON;
	case '=':  return EQUAL;
	}
	const string psi = "+-/*[],;^()";
	if (psi.find(c) != string::npos) return SYMBOL;
	if (c >= ' ' && c < '~') return OTHER;

	// unidentified
	setError("categorize()", c, "Invalid character found in source.");
	return UNKNOWN;
} // categorize()

//-----------------------------------------------------------------------------------
//                                 getFSAerror
//----------------------------------------------------------------------------------
string scanner::getFSAerror(CHAR_CAT cc, FSA_STATE state) {
	switch (state) {
	case START:
		if (cc == RBRACE) return "Beginning of comment expected.";
		return "Invalid beginning of lexeme.";
	case CMNT:  return "End of comment expected.";
	case SLIT:
		if (cc == EOL)  return "End of line found in string literal.";
		if (cc == EOFL) return "End of file found in string literal.";
		return "STATE=SLIT No transition from state found.";

	case SLITQ: return "Single quote expected.";
	case DECPT: return "Digit expected.";
	default:    return "Unknown error for STATE=" + FSA_STATE_STR[state] + ".";
	}
} // getFSAerror()

//-----------------------------------------------------------------------------------
//                                 getTrans
//-----------------------------------------------------------------------------------
int scanner::getTrans(FSA_STATE currState, char c) {
	CHAR_CAT cc = categorize(c);
	if (is_error) return -1;
	char la = f.peek();
	CHAR_CAT lacc = categorize(f.peek());

	for (int i = 0; i < NUM_FSA_TRANS; i++) {
		if ((trans[i].from == currState) &&
			(trans[i].ccat == cc || trans[i].ccat == ANY) &&
			(trans[i].la == lacc || trans[i].la == ANY))
			return i;
	}
	setError("getTrans()", c, getFSAerror(cc,currState));
	return -1;
} // getTrans()

//-----------------------------------------------------------------------------------
//                                 getNextLexeme
//-----------------------------------------------------------------------------------
string scanner::getNextLexeme() { 
	FSA_STATE state = START;
	char c;
	int  transNo;
	string lex = "";

	while (state != HALT && !is_error) {
		c = f.get();
		transNo = getTrans(state, c);
		//cout << "c=" << c << " state=" << FSA_STATE_STR[state] << " category=" << CHAR_CAT_STR[categorize(c)] << endl;
		if (!is_error) {
			if (trans[transNo].to == ERR)
				setError("getNextLexeme()", c, getFSAerror(categorize(c), state));
			else {
				state = trans[transNo].to;
				if (trans[transNo].act == KEEP)
					lex += c;
				else if (trans[transNo].act == PUTB) {
					if (f.fail()) f.clear();
					f.putback(c);
				}
				// else discard c
			}
		}
	}

	if (is_error) return ""; else return lex;
} // getNextLexeme()

//-----------------------------------------------------------------------------------
//                                 setError
//-----------------------------------------------------------------------------------
void scanner::setError(string method, char c, string msg) {
	string sc = " ";
	sc[0] = c;
	error = "SCANERROR::" + method + "  Line=" + to_string(lineNo) + " Character=";
	int ascii = (int)c;
	if (ascii <= 32 || ascii >= 127)
		error += "UNPRINTABLE (";
	else
		error += "'" + sc + "' (";
	error += to_string(ascii) + ")\n" + msg;
	is_error = true;
} // setError()


