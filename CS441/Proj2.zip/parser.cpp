#include <iostream>
#include "parser.h"
#include "prints.h"
string parser::compile(string fn)
{
	//open file
	scan.open(fn);
	//initialize LHS
	nextToken = scan.getNextToken();
	//push(S)
	token start;
	start.setId(TOK_N_PROGRAM);
	tokStack.push(start);
	//while everything isn't empty and theres no error
	while (!tokStack.empty() && nextToken.getId() != TOK_EOS && parseError == "" && !scan.isError()) 
	{
		//top = pop()
		top = tokStack.top();	
		tokStack.pop();
		//if top is a Non Terminal
		if (isNonTerminal(top))
		{
			//Find a production [if none, Error]
			int production = selectProd();
			if (production == -1)
				return "No production found for top=" + TOKENID_STR[top.getId()] + " next token=" + TOKENID_STR[nextToken.getId()];;
			pushProdRHS(production);
			cout << "TEST: PROD SELECTED=";
			//push(R) in right-to-left order
			printProduction(production);
		}
		//if top is a terminal
		else if (!isNonTerminal(top))
		{
			//if nextToken matches top
			if (nextToken.getId() == top.getId())
			{
				//consume
				cout << "TEST: " + TOKENID_STR[nextToken.getId()] + " consumed" << endl;
				nextToken = scan.getNextToken();
			}
			else //else error
				return TOKENID_STR[top.getId()] + " expected";
		}		
	}
	//if everything is empty and no error
	if (tokStack.empty() && nextToken.getId() == TOK_EOS && parseError == "" && !scan.isError())
		return ""; //accept
	else if (scan.isError()) //theres a scan error
		return scan.getError(); //reject
	else
	{
		if (nextToken.getId() == TOK_EOS) //theres an EOS before the stack is empty
			return "Unexpected end of source."; //reject
		else if (tokStack.empty()) //the stack is empty but haven't reached EOS
			return "Extra tokens at end of source."; //reject
	}
}

//searches for a production that can be used
int parser::selectProd()
{
	for (int i = 0; i < GR_NUMPRODS; i++)
	{
		if (PROD[i][0] == top.getId()) {
			for (int j = GR_FIRST_SELSET; j <= GR_LAST_SELSET; j++)
			{
				if (PROD[i][j] == nextToken.getId() || PROD[i][j] == TOK_DEFAULT)
				{
					return i;
				}
			}
		}
	}
	return -1;
}

bool parser::isNonTerminal(token t)
{		
	return ((t.getId() >= FIRST_NON_TERMINAL) && (t.getId() <= LAST_NON_TERMINAL));
}

//pushes the production's RHS onto the stack
//starting with the rightmost element in the production
void parser::pushProdRHS(int prodNum)
{
	for (int i = GR_LAST_RHS; i >= GR_FIRST_RHS; i--)
	{
		if (PROD[prodNum][i] != E) {
			token t;
			t.setId(PROD[prodNum][i]);
			tokStack.push(t);
		}
	}
}

