enum FSA_STATE {
        HALT, START, CMNT, ERR, ID, INT, DECPT, FRAC, SLIT, SLITQ, GTHAN, LTHAN, DOT
};

// FSA character categories
enum CHAR_CAT {
        UNKNOWN, ANY, WHITESP, EOFL, EOL, LBRACE, RBRACE, ALPHA, DIGIT, UNDERSC, DOTC,
        QUOTE, GTHANC, LTHANC, COLON, EQUAL, SYMBOL, OTHER
};

// FSA actions
enum ACTION { KEEP, DISC, PUTB };

// A Transition between two states based on a character category and look ahead,
// specifying the TO state and the action to take with the character
struct transition {
        FSA_STATE from;
        FSA_STATE to;
        CHAR_CAT  ccat;
        CHAR_CAT  la;
        ACTION    act;
};
//FSA transitions
const int NUM_FSA_TRANS = 42;
const transition trans[NUM_FSA_TRANS] = {
        //{TO,  FROM,  CCAT,    LA,  ACTION}
        {START, START, WHITESP, ANY, DISC},
        {START, START, EOL, ANY, DISC},
        {START, CMNT, LBRACE, ANY, DISC},
        {CMNT, START, RBRACE, ANY, DISC},
        {CMNT, ERR, EOFL, ANY, KEEP},
        {CMNT, CMNT, OTHER, ANY, DISC},
        {START, HALT, EOFL, ANY, KEEP},
        {START, ID, ALPHA, ANY, KEEP},
        {ID, ID, ALPHA, ANY, KEEP},
        {ID, ID, DIGIT, ANY, KEEP},
        {ID, ID, UNDERSC, ANY, KEEP},
        {ID, HALT, OTHER, ANY, PUTB},
        {START, INT, DIGIT, ANY, KEEP},
        {INT, INT, DIGIT, ANY, KEEP},
        {INT, HALT, DOTC, DOTC, PUTB},
        {INT, DECPT, DOTC, ANY, KEEP},
        {INT, HALT, OTHER, ANY, PUTB},
        {DECPT, FRAC, DIGIT, ANY, KEEP},
        {DECPT, ERR, OTHER, ANY, KEEP},
        {FRAC, FRAC, DIGIT, ANY, KEEP},
        {FRAC, HALT, OTHER, ANY, PUTB},
        {START, SLIT, QUOTE, ANY, KEEP},
        {SLIT, SLITQ, QUOTE, QUOTE, KEEP},
        {SLIT, HALT, QUOTE, ANY, KEEP},
        {SLIT, ERR, EOFL, ANY, KEEP},
        {SLIT, ERR, EOL, ANY, KEEP},
        {SLIT, SLIT, OTHER, ANY, KEEP},
        {SLITQ, SLIT, QUOTE, ANY, KEEP},
        {START, DOT, DOTC, ANY, KEEP},
        {DOT, HALT, DOTC, ANY, KEEP},
        {DOT, HALT, OTHER, ANY, PUTB},
        {START, LTHAN, LTHANC, ANY, KEEP},
        {LTHAN, HALT, EQUAL, ANY, KEEP},
        {LTHAN, HALT, GTHANC, ANY, KEEP},
        {LTHAN, HALT, OTHER, ANY, PUTB},
        {START, GTHAN, GTHANC, ANY, KEEP},
        {START, GTHAN, COLON, ANY, KEEP},
        {GTHAN, HALT, EQUAL, ANY, KEEP},
        {GTHAN, HALT, OTHER, ANY, PUTB},
        {START, HALT, EQUAL, ANY, KEEP},
        {START, HALT, SYMBOL, ANY, KEEP},
        {START, ERR, OTHER, ANY, KEEP}
};

