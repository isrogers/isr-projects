#include <string>
#include <fstream>
#include "fsa.h"
using namespace std;
class scanner {
public:
	int open(string source);
	string getNextLexeme();
	string getError();
	bool isError();
private: // suggested, but not required
	string error = "";
	bool is_error = false;
	int lineNo = 1;
	ifstream f;
	char readChar(bool isLA, CHAR_CAT &ccat); //defines readChar helper function which returns a char
	void getErrorMsg(string method, FSA_STATE state, char c, CHAR_CAT ccat); //defines getErrorMsg helper function which gets the error message
	void getCharCat(char c, CHAR_CAT &ccat); //defines getCharCat help function which gets character category
	//defines transitionToNextState which determines what the next state should be
	void transitionToNextState(FSA_STATE state, FSA_STATE &nextState, CHAR_CAT ccat, CHAR_CAT lacat, ACTION &action);
};
