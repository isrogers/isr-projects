//--------------scanner.cpp----------------
//AUTHOR:	IAN ROGERS
//DATE:		10/21/19
//COURSE:	CS441G - PROJECT 1.2
//INSTRUCTOR:	K. JOINER
//-----------------------------------------

#include <iostream>
#include <cctype>
#include "scanner.h"

//----------------OPEN--------------------
//INPUT:	the filename as a string
//RETURNS:	1 if opened successfully
//		0 if opened unsuccessfully
//DESC:		attempts to open file
//----------------------------------------		
int scanner::open(string filename)
{
	//ERROR if filename is empty
	if (filename == "")
	{
		//call getErrorMsg to print error message
		getErrorMsg("open()", HALT, -1, UNKNOWN);
		return 0; 
	}else
	{
		f.open(filename);
		//ERROR if failure to open file
		if (f.fail())
		{
			getErrorMsg("open()", HALT, -1, UNKNOWN);
			return 0;			
		}else return 1;	
	}
} //OPEN

//----------------GETNEXTLEXEME--------------------
//INPUT:	N/A
//RETURNS:	the lexeme on a successful halt state
//		"" on an EOFL or ERROR
//DESC:		attempts to get the next lexeme
//-------------------------------------------------
string scanner::getNextLexeme()
{
	string lex;
	//declare the state as START
	FSA_STATE state = START;
	//while loop that runs as long as the state isn't HALT/ERR
	//this should never stop running without a return
	while ((state != HALT) && (state != ERR))
	{
		FSA_STATE nextState;
		CHAR_CAT ccat, lacat;
		ACTION action;
		//declare isLA which is passed into the readChar helper function
		//if isLA is false, the function assumes it isn't reading a lookahead
		bool isLA = false;
		char c = readChar(isLA, ccat); //call readChar
		isLA = true; //set isLA to true
		char la = readChar(isLA, lacat); //call readChar
		
		//if ccat/lacat aren't set to EOFL in readChar
		//call getCharCat to get the category of the character
		//we check for EOFL because getCharCat doesn't check for an EOFL
		if (ccat != EOFL)
			getCharCat(c, ccat); //call getCharCat
		if (lacat != EOFL)
			getCharCat(la, lacat); //call getCharCat

		//call transitionToNextState which takes nextState and action as PBRs
		transitionToNextState(state, nextState, ccat, lacat, action);
		
		//if the nextState, is ERR print error message and return ""
		if (nextState == ERR)
		{
			getErrorMsg("getNextLexeme()", state, c, ccat);
			return ""; 
		}
		//if nextState is HALT, but not at EOFL does the action given by transitionToNextState
		if ((nextState == HALT) && (ccat != EOFL))
		{
			//if action is PUTB, it puts the char back on the stream and returns the lex
			if (action == PUTB)
			{
				f.putback(c);
				return lex;
			}
			//if the action is KEEP, adds the char to the the lexeme and returns it
			if (action == KEEP)
			{
				lex += c;
				return lex;
			} //does nothing if action is DISC
		}
		//if nextState is HALT and at EOFL, return ""
		if ((nextState == HALT) && (ccat == EOFL))
			return "";
		//if action is PUTB, puts the char back on the stream and returns the lex
		if (action == PUTB)
		{
			f.putback(c);
			return lex;
		}
		//if action is KEEP, adds the char to the lexeme
		else if (action == KEEP)
			lex += c;
		//set state to the nextState
		state = nextState;
	}
} //GETNEXTLEXEME

//----------------READCHAR------------------------
//INPUT:	bool isLA, CHAR_CAT ccat as PBR
//RETURNS:	the next character in the stream (non-LA)
//		the character after the next on the stream (LA)
//DESC:		reads the next character
//-------------------------------------------------
char scanner::readChar(bool isLA, CHAR_CAT &ccat)
{
	//declares c
	char c;
	//if not a LA, use get from fstream
	if (isLA == false)
		c = f.get();
	else //if LA use peek
		c = f.peek();
	//if c is EOF, set the ccat as EOF
	if (c == EOF)
		ccat = EOFL;
	//if c is a newline character, add one to lineNo
	else if ((c == '\n') && (isLA == false))
		lineNo++;
	return c; //return
} //READCHAR

//----------------GETCHARCAT------------------------
//INPUT:	char c, CHAR_CAT ccat as PBR
//RETURNS:	void
//DESC:		gets the category, ccat, of character c
//--------------------------------------------------
void scanner::getCharCat(char c, CHAR_CAT &ccat)
{
	//a series of if statements that determine which category ccat is.
	if (c == '\n') ccat = EOL;		//EOL
	else if (isspace(c)) ccat = WHITESP;	//WHITESP
	else if (isdigit(c)) ccat = DIGIT;	//DIGIT
	else if (isalpha(c)) ccat = ALPHA;	//ALPHA
	else if (c == '{') ccat = LBRACE;	//LBRACE
	else if (c == '}') ccat = RBRACE;	//RBRACE
	else if (c == '_') ccat = UNDERSC; 	//UNDERSC
	else if (c == '.') ccat = DOTC;		//DOTC
	else if (c == '\'') ccat = QUOTE;	//QUOTE
	else if (c == '>') ccat = GTHANC;	//GTHANC
	else if (c == '<') ccat = LTHANC;	//LTHANC
	else if (c == ':') ccat = COLON;	//COLON
	else if (c == '=') ccat = EQUAL;	//EQUAL
	//SYMBOL
	else if  (c == '+' || c == '-' || c == '/' || c == '[' || c == ']' || c == ',' || c == ';' || c == '^'|| c == '*' || c == '(' || c == ')')
		ccat = SYMBOL;
	//OTHER
	else if (c >= ' ' && c < '~') ccat = OTHER;
	//UNKNOWN - calls getErrorMsg to print error if cat is unknown
	else	
	{	
		ccat = UNKNOWN;
		getErrorMsg("getCharCat()", HALT, c, ccat);	
	}
} //GETCHARCAT

//----------------TRANSITIONTONEXTSTATE------------------------
//INPUT:	FSA_STATE state, nextState as PBR, CHAR_CAT ccat, lacat, ACTION action as PBR
//RETURNS:	void
//DESC:		figures out what the nextState is and what the ACTION of this state is
//--------------------------------------------------
void scanner::transitionToNextState(FSA_STATE state, FSA_STATE &nextState, CHAR_CAT ccat, CHAR_CAT lacat, ACTION &action)
{
	//declares bool isCalled which is set to true if inner if statements are called
	bool isCalled = false;
	//for loop which runs through all possible transitions
	for (int i = 0; i < NUM_FSA_TRANS; i++)
	{
		//if states match
		if ((state == trans[i].from))
		{
			//and ccats match
			//also checks for ccat OTHER
			//OTHER is used as "any other char" in the fsa
			//if trans.ccat is OTHER, there should be a match unless the inner loop was already called
			if (((ccat == trans[i].ccat) || (trans[i].ccat == OTHER)) && !isCalled)
			{
				//checks la for any/match
				if (trans[i].la == ANY)
				{
					isCalled = true;
					nextState = trans[i].to;
					action = trans[i].act;
				}else if (lacat == trans[i].la)
				{
					isCalled = true;
					nextState = trans[i].to;
					action = trans[i].act;
				}
			}
		}
	}
}//TRANSITIONTONEXTSTATE

//----------------GETERRORMSG------------------------
//INPUT:	string method, FSA_STATE state, char c, CHAR_CAT ccat
//RETURNS:	void
//DESC:		figures out what the error message should be
//---------------------------------------------------
void scanner::getErrorMsg(string method, FSA_STATE state, char c, CHAR_CAT ccat)
{	
	//sets is_error to true
	is_error = true;
	//declares strings errorMsg and charMsg as ""
	string errorMsg = "";
	string charMsg = "";
	//declares asci as the ascii code of char c
	int asci = (int) c;
	//if the ascii is outside of the range, the message is UNPRINTABLE
	if (asci <= 32 || asci >=127)
		charMsg = "UNPRINTABLE";
	else //message is just the character
		charMsg = c;
	//if method was open/getCharCat, sets generic error as errorMsg
	if (method == "open()")
		errorMsg = "Unable to open input file.";
	if (method == "getCharCat()")
		errorMsg = "Invalid character found in source."; 
	if (state == START)
	{
		//if right brace comes before left brace, then sets errorMsg
		if (ccat == RBRACE)
			errorMsg = "Beginning of comment expected.";
		//else there was an invalid start to lexeme, sets errorMsg
		else
			errorMsg = "Invalid beginning of lexeme.";
	}
	//if there wasn't an end to comment, set errorMsg
	if ((state == CMNT) && (ccat == EOFL))
		errorMsg = "End of comment expected.";
	if (state == SLIT)
	{
		//if EOL found within string literal, set errorMsg
		if (ccat == EOL)
			errorMsg = "End of line found in string literal.";
		//if EOFL found within string literal, set errorMsg
		else if (ccat == EOFL)
			errorMsg = "End of file found in string literal.";
		//else SLIT transition error
		else
			errorMsg = "STATE=SLIT No transition from state found.";
	}
	//if the state is DECPT, set errorMsg
	if (state == DECPT)
		errorMsg = "Digit expected.";
	//if the errorMsg hasn't been set, set error as unknown error
	//this should never happen
	if (errorMsg == "")
		errorMsg = "Unknown error.";
	//sets the error message in error variable
	error = "SCAN ERRROR::" + method + " Line=" + to_string(lineNo) + " Character='" + charMsg + "' (" + to_string(asci) + ")\n" + errorMsg; 
}//GETERRORMESSAGE

//----------------ISERROR------------------------
//RETURNS:	error status (is_error)
//-----------------------------------------------
bool scanner::isError()
{
	return is_error;
} //GETERRORMSG

//---------------GETERROR------------------------
//RETURNS:	error message (error)
//-----------------------------------------------
string scanner::getError()
{
	return error;
}//GETERROR
