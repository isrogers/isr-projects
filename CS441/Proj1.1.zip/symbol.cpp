//symbol.cpp
//Ian Rogers
//9-10-19
//Proj1.1



#include "symbol.h"
#include <ctype.h> //for isalpha() and isdigit()
//-----------------------------------------------------
//						constructor
//-----------------------------------------------------
symbol::symbol() {
	lexeme = "";
	category = dataType = 0;
	next = NULL;
}

//-----------------------------------------------------
//					simple gets/sets
//-----------------------------------------------------
void   symbol::setDataType(int dt) { dataType = dt; }
string symbol::getLex() { return lexeme; }
int    symbol::getCategory() { return category; }
int    symbol::getDataType() { return dataType; }

//-----------------------------------------------------
//					    setLex
//-----------------------------------------------------
void	symbol::setLex(string lex) {
	lexeme = lex;
	if (isalpha(lexeme[0])){		//check if the lexeme is alphabetical
		category = SYMCAT_IDENT;	//making it an identifier
		dataType = DTYPE_UNKNOWN;
	}
	else if (lexeme[0]== '"' || lexeme[0]== '\''){	//check if the lexeme starts with quotes
		category = SYMCAT_STRING_LIT;		//making it a string lit
		dataType = DTYPE_STRING;
	}
	else if (isdigit(lexeme[0])){			//check if the lexeme starts with a digit
		for (int i=0; lexeme[i] != '\0'; i++){	//making it a real lit or an int lit
			if (lexeme[i] == '.'){		//if it contains a decimal point it is a real lit
				category = SYMCAT_REAL_LIT;
				dataType = DTYPE_REAL;
			}
		}
		if (category == 0 && dataType == 0){	//if no decimal, it is an int lit
			category = SYMCAT_INT_LIT;
 			dataType = DTYPE_INT;
		}
	}			
} // setLex()
