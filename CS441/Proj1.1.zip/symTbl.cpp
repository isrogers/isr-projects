//symTbl.cpp
//Ian Rogers
//9-10-19
//Proj1.1

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include "symTbl.h"

//------------------- constructor ------------------
symTbl::symTbl() {
	for (int i = 0; i < SYMTBL_NUM_BUCKETS; i++)
		bucket[i] = NULL;
} // constructor

//--------------------  insert  -------------------
symTblRef symTbl::insert(string newlex) {
	symTblRef p = search(newlex);	//search for lexeme
	if (p == NULL){	//if the lexeme doesn't exist - create it
		p = new symbol;	//create a new symbol object & set the lexeme
		p->setLex(newlex);	
		int bucketNum = hash(newlex);	//find the bucket
		if (bucket[bucketNum] == NULL){	//the bucket is empty
			bucket[bucketNum] = p;	//fill the bucket
		}
		else {	//the bucket is filled
			symTblRef temp = p;	//implement push in the context of a list to fill bucket	
			temp->next = bucket[bucketNum];	
			bucket[bucketNum] = temp;	
		}
		return bucket[bucketNum];	//return the pointer to the bucket
						//the newly allocated node is the first node
	}	
	else //the lexeme already exists
		return p; //return the symbol table ref 
} // insert()

//--------------------- hash ---------------------
int symTbl::hash(string lex) {
	int sum = 0;	
	for (int i = 0; lex[i] != '\0'; i++)	//sum of ascii chars
		sum = sum + (int)lex[i];
	int bucketNum = sum % SYMTBL_NUM_BUCKETS; //sum mod # of buckets
	return bucketNum;	//return bucket #
} // hash()

//---------------------- search ---------------------
symTblRef symTbl::search(string search4) {
	symTblRef p; 
	int bucketNum = hash(search4);	//call hash to find bucket #
	if (bucket[bucketNum] != NULL){	//if the bucket isn't empty search for lexeme
		p = bucket[bucketNum];	
		while(p){	//search through the list for a match
			if (p->getLex() == search4)
				return p;	//return the match
			p = p->next;
		}
	}
	else	//if the bucket is empty/lex isn't in the list returns NULL
		return NULL;	
} // search()

//---------------------- print ---------------------
void symTbl::print() {
	int numEntries = 0;  
	cout << "---------- SYMBOL TABLE ------------\n";
	for (int i = 0; i < SYMTBL_NUM_BUCKETS; i++) {
		// only print bucket if it has an entry
		if (bucket[i] != NULL) {
			// print first entry in this bucket with bucket #
			symTblRef p = bucket[i];
			cout << "[" << setw(3) << i << "]: ";
			cout << "cat=" << p->getCategory()
				<< "  dtype=" << p->getDataType()
				<< "  lex=" << p->getLex() << endl;
			numEntries++;
			p = bucket[i]->next;

			// print all other entries in this bucket
			while (p) {
				cout << "       cat=" << p->getCategory()
					<< "  dtype=" << p->getDataType()
					<< "  lex=" << p->getLex() << endl;
				numEntries++;
				p = p->next;
			} // while more entries in bucket
		} // if bucket not empty
	} // for all buckets
	cout << "------------------------------------\n";
	cout << "Number of entries: " << numEntries << endl << endl;
	cout << "Press any key to continue..";
	getchar();
} // print()
